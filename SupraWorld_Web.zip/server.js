const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static("public"));

const players = new Map();
const PORT = process.env.PORT || 3000;

io.on("connection", (socket) => {
  socket.on("join", (rawName) => {
    const name = String(rawName || "Player").trim().slice(0, 18) || "Player";
    const player = { id: socket.id, name, x: 0, y: 0, z: 0, rot: 0, color: Math.floor(Math.random()*0xffffff) };
    players.set(socket.id, player);
    socket.emit("welcome", { id: socket.id, players: [...players.values()] });
    socket.broadcast.emit("playerJoined", player);
  });

  socket.on("move", (data) => {
    const p = players.get(socket.id);
    if (!p || !data) return;
    p.x = clamp(Number(data.x) || 0, -200, 200);
    p.y = 0;
    p.z = clamp(Number(data.z) || 0, -200, 200);
    p.rot = Number(data.rot) || 0;
    socket.broadcast.emit("playerMoved", p);
  });

  socket.on("chat", (rawMessage) => {
    const p = players.get(socket.id);
    if (!p) return;
    const message = String(rawMessage || "").trim().slice(0, 180);
    if (!message) return;
    io.emit("chat", { name: p.name, message, time: Date.now() });
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
    io.emit("playerLeft", socket.id);
  });
});

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

server.listen(PORT, "0.0.0.0", () => {
  console.log(`SUPRA WORLD server running on port ${PORT}`);
});
